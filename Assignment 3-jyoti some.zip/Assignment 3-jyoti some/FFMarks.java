package com.cdac.main;



import java.util.Scanner;



class CMarks{
//	int avg;
	int add;
	int rollno=1;
	int marks;
	String name;
	
	CMarks(){
		
	}
	CMarks(String name){
		this.name=name;
	}
	void mark(){
		this.marks=0;
	}
//	void average(){
//		this.marks=+avg;
//	}
	public void addition(int add) {
		this.marks=+add;
	}
}

class CPhysics extends CMarks {
	int phymarks;
	CPhysics(){
		this.phymarks=0;
	}
	int physicsmarks(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your physics marks: ");
		phymarks=sc.nextInt();
		this.phymarks=+phymarks;
		this.add=phymarks;
		return phymarks;
	}

}
class CMaths extends CMarks{
	int mathmarks;
	CMaths(){
		this.mathmarks=0;
	}
	int mathsmarks(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your maths marks: ");
		mathmarks=sc.nextInt();
		this.mathmarks=+mathmarks;
		this.add=mathmarks;
		return mathmarks;
		
	}
}
class CChemistry extends CMarks{
	int chemarks;
	CChemistry(){
		this.chemarks=0;
	}
	int chemistrymarks(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your chemistry marks: ");
		chemarks=sc.nextInt();
		this.chemarks=+chemarks;
		this.add=chemarks;
		return chemarks;
	}	
}

public class FFMarks {
	
	static void display() {
		CMarks c=new CMarks();
		CPhysics cp=new CPhysics();
		CMaths cm=new CMaths();
		CChemistry hm=new CChemistry();
//		c.marks=cp.phymarks+cm.mathmarks+hm.chemarks;
//		System.out.println(c.marks);
		cp.addition(0);
	}
	
	public static void main(String[] args) {
		CPhysics cp=new CPhysics();
		cp.physicsmarks();
		CMaths cm=new CMaths();
		cm.mathsmarks();
		CChemistry hm=new CChemistry();
		hm.chemistrymarks();
		
		FFMarks.display();
		

	}

}

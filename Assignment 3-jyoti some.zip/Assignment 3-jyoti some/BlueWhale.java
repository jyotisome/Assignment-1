package com.cdac.main;	
class Mammals {
	void mammals() {
		System.out.println("i am mammal");
		
	}
	
}
class MarineAnimals extends Mammals{
	void MarineAnimals1(){
		System.out.println("i am Marine Animal");
		
	}
	
}
public class BlueWhale extends MarineAnimals {
	void BlueWhale1() {
	System.out.println("I belong to both the categories: Mammals as well as Marine Animals");
	}
	public static void main(String[] args) {
		BlueWhale b=new BlueWhale();
		b.BlueWhale1();
		MarineAnimals ma  =new MarineAnimals();
		ma.MarineAnimals1();
		Mammals m=new Mammals();
		m.mammals();
		
	}
	
}







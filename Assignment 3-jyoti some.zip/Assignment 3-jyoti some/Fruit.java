package com.cdac.main;

import java.util.Scanner;
 class Apple{
	 int a;
	 void app(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of Apples:"); 
		a=sc.nextInt();
		
	 }

}
 class Mangoes extends Apple{
	 int m;
	 void man(){
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter the number of Mangoes:"); 
		 m=sc.nextInt();
		 

		 }
	 
 }
 public class Fruit extends Mangoes{
	 int fruitbasket;
	 
	 void cal() {
		 fruitbasket=a+m;
		 System.out.println("total number of fruits in the basket:"+fruitbasket);
		 
	 }
	 public static void main(String[] args) { 
	 Scanner sc=new Scanner(System.in);
	 Fruit  f1=new Fruit();
	 f1.app();
	 f1.man();
	 f1.cal();
	 
	 
	 }
 }

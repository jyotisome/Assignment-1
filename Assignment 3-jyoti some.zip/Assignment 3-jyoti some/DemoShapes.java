package com.cdac.main;

class Shape{
	 void printshape() {
		System.out.println("This is a shape");
	}
}

class Polygon extends Shape{
	void printpolygon() {
		System.out.println("Polygon is a shape");
	}
}
class Rectangle9 extends Polygon{
	void printpolygon() {
		System.out.println("Rectangle is a polygon");
	}
}
class Triangle extends Polygon{
	void printpolygon() {
		System.out.println("Triangle is a polygon");
	}
}

class Square extends Polygon{
	void printpolygon() {
		System.out.println("Square is a rectangle");
	}
}
public class DemoShapes {

	public static void main(String[] args) {
		DemoShapes ds=new DemoShapes();
		Shape s=new Shape();
		s.printshape();
		Polygon p=new Polygon();
		p.printpolygon();
		Rectangle9 r=new Rectangle9();
		r.printpolygon();
		Triangle t=new Triangle();
		t.printpolygon();
		Square sq=new Square();
		sq.printpolygon();
		

	}

	
}

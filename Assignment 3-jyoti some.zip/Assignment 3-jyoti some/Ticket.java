
package exception;
import java.util.Scanner;

public class Ticket {
	static int ticketId;
	static double ticketprice;
	static int availableticket;
	static int initialQuantity;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ticketbookingsystem a=new ticketbookingsystem();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the ticket price");
		int price=scan.nextInt();
		System.out.println("enter the total quantity of the ticket to be loaded");
		int quant=scan.nextInt();
		a.add(0, price, quant);
		Ticket.display();		
	}
	static void display() {
		Scanner scan=new Scanner(System.in);
		ticketbookingsystem a=new ticketbookingsystem();
		//ticketbookingsystem c=new ticketbookingsystem();
		
		System.out.println("1)for ticket booking");
		System.out.println("2)for ticket cancellation");
		int y=scan.nextInt();
		switch (y) {
		case 1:
			System.out.println("enter the quantity of the ticket to be booked");
			int book=scan.nextInt();
			try {
				try {
					a.bookticket(0, book);
				} catch (InvalidTicketQuantityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (InsufficientTicketsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Ticket.display();
			}			
			break;
		case 2:
			System.out.println("enter the quantity of ticket to be cancelled");
			int cancel=scan.nextInt();
			try {
				a.cancel_booking(0,cancel);
			} catch (InvalidTicketQuantityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Ticket.display();
			}
			//Ticket.display();
			break;

		default:
			break;
		}
	}
}
class InsufficientTicketsException extends Exception {
    public InsufficientTicketsException(String message) {
        super(message);
    }
}
class InvalidTicketQuantityException extends Exception {
    public InvalidTicketQuantityException(String message) {
        super(message);
    }
}
class TicketNotFoundException extends Exception {
    public TicketNotFoundException(String message) {
        super(message);
    }
}
class ticketbookingsystem extends Ticket{

	void add(int ticketId,double ticketPrice,int initialQuantity) {
		this.ticketprice=ticketPrice;
		this.initialQuantity=initialQuantity;
	}
	static void bookticket(int ticketId,int quantity)throws InsufficientTicketsException, InvalidTicketQuantityException {
		if(quantity<initialQuantity && quantity>0) {
			initialQuantity=initialQuantity-quantity;
			System.out.println("tikcets booked");
		}
		else {
			throw new InsufficientTicketsException("tickets are not available");
		}
		if(quantity<=0) {
			throw new InvalidTicketQuantityException("tickets cant be booked");
		}
		Ticket.display();		
	}
	void cancel_booking(int ticketId,int quantity) throws InvalidTicketQuantityException {
		if(quantity<initialQuantity) {
			initialQuantity=initialQuantity+quantity;
			System.out.println("tickets canceled");
		}
		else {
			throw new InvalidTicketQuantityException("invalid ticket cancellation");
		}
		Ticket.display();
	}
}

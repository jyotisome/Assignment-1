package com.cdac.main;

import java.util.*;

   class Vehicles {
	int mileage;
	float price;
	
	  void vehicle() {
		  Scanner sc=new Scanner(System.in);
//			System.out.println("enter the mileage of the car:");
//			mileage=sc.nextInt();
//			System.out.println("your mileage of the car is"+" "+mileage);
//			sc.nextLine();
//			System.out.println("eneter the price of the car:");
//			price=sc.nextInt();
//			System.out.println("your price of the car is"+" "+price);
//		
//		 
 }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

	 
	class Car extends Vehicles{
		int ownership_cost;
		int warranty_year;
		int seating_capacity;
		String fuel;
		
		void vehiclecar(){
			super.vehicle();
//			 Scanner sc=new Scanner(System.in);
//				System.out.println("enter the ownership_cost of the car:");
//				ownership_cost=sc.nextInt();
//				System.out.println("your mileage of the car is"+" "+ownership_cost);
//				
//				System.out.println("enter the warranty_year of the car:");
//				warranty_year=sc.nextInt();
//				System.out.println("your mileage of the car is"+" "+warranty_year);
//				
//				System.out.println("enter the seating_capacity of the car:");
//				seating_capacity=sc.nextInt();
//				System.out.println("your mileage of the car is"+" "+seating_capacity);
//				
//				System.out.print("Enter a choice  for fuel:\n"+"  "+"1.DIESEL\n"+"  "+"2.PETROL\n"+"  "+"3.OTHER");
//				int ch = sc.nextInt();
//				switch(ch) {
//				case 1: {
//					System.out.println("Diesel");
//					this.fuel="Diesel";
//					break;
//				}
//					
//						
//				case 2: System.out.println("petrol");
//				this.fuel="petrol";
//				break;
//				
//				default:System.out.println("Kuch bhi mat daal");
//				this.fuel="Kuch bhi mat daal";
//				}
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////
	
	class Bike extends Vehicles {
		 int cyclinders;
		 int gears;
		 String cooling_type;
		 String wheel_type;
		 int fuel_tank_size;
		 
		 void vehiclebike(){
			 super.vehicle();
//			 Scanner sc=new Scanner(System.in);
//			    System.out.println("enter the cyclinders of the bike:");
//			    cyclinders=sc.nextInt();
//				System.out.println("your cyclinders of the bike is"+" "+cyclinders);
//			 
//				System.out.println("enter the gears of the bike:");
//				gears=sc.nextInt();
//				System.out.println("your cyclinders of the bike is"+" "+gears);
//				
//				System.out.println("enter the cooling_type of the bike:");
//				cooling_type=sc.nextLine();
//				System.out.println("your cooling_type of the bike is"+" "+cooling_type);
//			 
//				System.out.println("enter the wheel_type of the bike:");
//				wheel_type=sc.nextLine();
//				System.out.println("your wheel_type of the bike is"+" "+wheel_type);
//			 
//				System.out.println("enter the fuel_tank_size of the bike:");
//				fuel_tank_size=sc.nextInt();
//				System.out.println("your fuel_tank_size of the car is"+" "+fuel_tank_size);
//			 
		 }
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	class audi extends Car{
		String model_type;
		
		
		int ownership_cost;
		int warranty_year;
		int seating_capacity;
		String fuel;
		int mileage;
		float price;
		
		void vehicleaudi() {
			super.vehicle();
			Scanner sc=new Scanner(System.in);
			System.out.println("********AUDI CAR DETAILS*********");
			System.out.println("enter the wheel_type of the  car:");
			model_type=sc.nextLine();
			System.out.println("your wheel_type of the  car is"+" "+model_type);
	
			System.out.println("enter the ownership_cost of the car:");
			ownership_cost=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+ownership_cost);
			
			System.out.println("enter the warranty_year of the car:");
			warranty_year=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+warranty_year);
			
			System.out.println("enter the seating_capacity of the car:");
			seating_capacity=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+seating_capacity);
			
			System.out.print("Enter a choice  for fuel:\n"+"  "+"1.DIESEL\n"+"  "+"2.PETROL\n"+"  "+"3.OTHER");
			int ch = sc.nextInt();
			switch(ch) {
			case 1: 
				System.out.println("Diesel");
				this.fuel="Diesel";
				break;
					
			case 2: System.out.println("petrol");
			this.fuel="petrol";
			break;
			
			default:System.out.println("Kuch bhi mat daal");
			this.fuel="Kuch bhi mat daal";
			}
			
			System.out.println("enter the mileage of the car:");
			mileage=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+mileage);
			System.out.println("eneter the price of the car:");
			price=sc.nextInt();
			System.out.println("your price of the car is"+" "+price);	
		 
			}
			
		}
/////////////////////////////////////////////////////////////////////	/////////////////////////////////////////////////////////////	
		
		

	class ford extends Car{
		String model_type;
		
		
	    int ownership_cost;
		int warranty_year;
		int seating_capacity;
	    String fuel;
		int mileage;
		float price;
		
		void vehicleford() {
			super.vehicle();
			Scanner sc=new Scanner(System.in);
			System.out.println("********FORD CAR DETAILS*********");
			System.out.println("enter the wheel_type of the model_type:");
			model_type=sc.nextLine();
			System.out.println("your wheel_type of the bike is"+" "+model_type);
	
			System.out.println("enter the ownership_cost of the car:");
			ownership_cost=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+ownership_cost);
			
			System.out.println("enter the warranty_year of the car:");
			warranty_year=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+warranty_year);
			
			System.out.println("enter the seating_capacity of the car:");
			seating_capacity=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+seating_capacity);
			
			System.out.print("Enter a choice  for fuel:\n"+"  "+"1.DIESEL\n"+"  "+"2.PETROL\n"+"  "+"3.OTHER");
			int ch = sc.nextInt();
			switch(ch) {
			case 1: 
				System.out.println("Diesel");
				this.fuel="Diesel";
				break;
			
			case 2: System.out.println("petrol");
			this.fuel="petrol";
			break;
			
			default:System.out.println("Kuch bhi mat daal");
			this.fuel="Kuch bhi mat daal";
			}
			
			System.out.println("enter the mileage of the car:");
			mileage=sc.nextInt();
			System.out.println("your mileage of the car is"+" "+mileage);
			System.out.println("eneter the price of the car:");
			price=sc.nextInt();
			System.out.println("your price of the car is"+" "+price);	
		 
			
		
	}
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	class bajaj extends Bike  {
		String make_type;
		
		int ownership_cost;
		int warranty_year;
		int seating_capacity;
		String fuel;
		int mileage;
		float price;
		
		
		void vehiclebajaj() {
			super.vehicle();
			Scanner sc=new Scanner(System.in);
			System.out.println("********BAJAJ BIKE DETAILS*********");
			System.out.println("enter the make_type of the model_type:");
			make_type=sc.nextLine();
			System.out.println("your make_type of the bike is"+" "+make_type);
	
			System.out.println("enter the ownership_cost of the bike:");
			ownership_cost=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+ownership_cost);
			
			System.out.println("enter the warranty_year of the bike:");
			warranty_year=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+warranty_year);
			
			System.out.println("enter the seating_capacity of the bike:");
			seating_capacity=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+seating_capacity);
			
			System.out.print("Enter a choice  for fuel:\n"+"  "+"1.DIESEL\n"+"  "+"2.PETROL\n"+"  "+"3.OTHER");
			int ch = sc.nextInt();
			switch(ch) {
			case 1: 
				System.out.println("Diesel");
				this.fuel="Diesel";
				break;
			
			case 2: System.out.println("petrol");
			this.fuel="petrol";
			break;
			
			default:System.out.println("Kuch bhi mat daal");
			this.fuel="Kuch bhi mat daal";
			}
			
			System.out.println("enter the mileage of the bike:");
			mileage=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+mileage);
			System.out.println("eneter the price of the bike:");
			price=sc.nextInt();
			System.out.println("your price of the bike is"+" "+price);	
		 
			
		}
		
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	class TVS extends Bike{ 
		String make_type;
		
		int ownership_cost;
		int warranty_year;
		int seating_capacity;
		String fuel;
		int mileage;
		float price;
		
		
		void vehicletvs() {
			super.vehicle();
			Scanner sc=new Scanner(System.in);
			System.out.println("********TVS BIKE DETAILS*********");
			System.out.println("enter the make_type of the model_type:");
			make_type=sc.nextLine();
			System.out.println("your make_type of the bike is"+" "+make_type);
			
			System.out.println("enter the ownership_cost of the bike:");
			ownership_cost=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+ownership_cost);
			
			System.out.println("enter the warranty_year of the bike:");
			warranty_year=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+warranty_year);
			
			System.out.println("enter the seating_capacity of the bike:");
			seating_capacity=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+seating_capacity);
			
			System.out.print("Enter a choice  for fuel:\n"+"  "+"1.DIESEL\n"+"  "+"2.PETROL\n"+"  "+"3.OTHER");
			int ch = sc.nextInt();
			switch(ch) {
			case 1: 
				System.out.println("Diesel");
				this.fuel="Diesel";
				break;
			
			case 2: System.out.println("petrol");
			this.fuel="petrol";
			break;
			
			default:System.out.println("Kuch bhi mat daal");
			this.fuel="Kuch bhi mat daal";
			}
			
			System.out.println("enter the mileage of the bike:");
			mileage=sc.nextInt();
			System.out.println("your mileage of the bike is"+" "+mileage);
			System.out.println("eneter the price of the bike:");
			price=sc.nextInt();
			System.out.println("your price of the bike is"+" "+price);	
		 
		}
	
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


public class DemoVehicleNew {
	public static  void main(String[] args) {
		DemoVehicleNew z1=new DemoVehicleNew();
//	Vehicles v1=new Vehicles();
//	v1.vehicle();
////		Car v2=new Car();
//		Bike v3=new Bike();
		audi v4=new audi();
		v4.vehicleaudi();
		ford v5=new ford();
		v5.vehicleford();
		bajaj v6=new bajaj();
		v6.vehiclebajaj();
		TVS v7=new TVS();
		v7.vehicletvs();
	
//		v1.vehicle();
//		v2.c();
//		v3.b();
//		v4.au();
//		v5.f();
//		v6.ba();
//		v7.tvs();
		
		

	}

	}



package com.cdac.main;

class VehicleDemo{
	String make;
	String model;
	int year;
	String color;
	
	VehicleDemo() {
		String make ="";
		String model="";
		int year=0;
		String color="";
		System.out.println("I am default constructor in vehicle");
	}
		
	VehicleDemo(String make, String model,int year,String color){
			this.make=make;
			this.model=model;
			this.year=year;
			this.color=color;
			System.out.println("I am parameterize constructor in vehicle");
		}
	VehicleDemo(String make, String model,int year){
		color="unknown";
		System.out.println("color is unknown");
		
	}
}
	class Car4 extends VehicleDemo{
		int numDoors;
		boolean automatic;
		 
		Car4(){
			 super();
			 int numDoors=0;
			 boolean automatic=false; 
			 System.out.println("I am default constructor in Car");
		 }
		Car4(int numDoors, boolean automatic){
			super();
			this.numDoors=numDoors;
			this.automatic=automatic;
			System.out.println("I am parameterized constructor of Car");
		}
		
		Car4(String make, String model, int year){
			super();
			numDoors=0;
			automatic=false;
			System.out.println("I am same constructor in Car");
		}
		
	}
	   class Truck extends VehicleDemo{
		   double payloadCapacity;
		   double towingCapacity;
		
		   Truck(){
			   super();
			   double payloadCapacity=0.0;
			   double towingCapacity=0.0;
			   System.out.println("I am default constructor in truck");
			   
		   }
		   Truck(double payloadCapacity,double towingCapacity){
			   super();
			   this.payloadCapacity=payloadCapacity;
			   this.towingCapacity=towingCapacity;
			   System.out.println("I am parametrized constructor in truck");
		   }
		   Truck(String make, String model, int year){
			    payloadCapacity=0.0;
			    towingCapacity=0.0;
			   System.out.println("I am same constructor in truck");
			   
		   }
		   
	   }
		
public class ChaningClass {

	public static void main(String[] args) {
		Car4 c5=new Car4();
		System.out.println("\n");
	
		Car4 c6=new Car4(5,true);
		System.out.println("\n");
		
		Car4 c7=new Car4("India","ABC",2022);
		System.out.println("\n");
		System.out.println("\n");
		
		
		Truck t5=new Truck();
		System.out.println("\n");
		
		Truck t6=new Truck(1234.56,7896.54);
		System.out.println("\n");
		
		Truck t7=new Truck("America","XYZ",2023);
		
	}

}
